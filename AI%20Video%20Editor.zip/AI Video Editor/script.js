// Google Client ID: Google Cloud Console থেকে নিজের Client ID বসান।
const GOOGLE_CLIENT_ID = "YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com";
const video = document.getElementById('mainVideo');
let currentVideoUrl = null;

window.addEventListener('load', () => {
    const upload = document.getElementById('videoUpload');
    upload.addEventListener('change', handleVideoUpload);

    if (GOOGLE_CLIENT_ID.startsWith("YOUR_")) {
        showToast('Google লগইন চালু করতে script.js-এ Client ID বসান।');
        return;
    }

    if (window.google && google.accounts && google.accounts.id) {
        google.accounts.id.initialize({
            client_id: GOOGLE_CLIENT_ID,
            callback: handleCredentialResponse
        });
        google.accounts.id.renderButton(
            document.getElementById("googleBtnContainer"),
            { theme: "outline", size: "large", text: "signin_with" }
        );
    } else {
        showToast('Google Sign-In লোড হয়নি। ইন্টারনেট সংযোগ পরীক্ষা করুন।');
    }
});

function handleVideoUpload(event) {
    const file = event.target.files && event.target.files[0];
    if (!file) return;
    if (currentVideoUrl) URL.revokeObjectURL(currentVideoUrl);
    currentVideoUrl = URL.createObjectURL(file);
    video.src = currentVideoUrl;
    video.load();
    showToast('ভিডিও লোড হয়েছে।');
}

function handleCredentialResponse(response) {
    try {
        const payload = decodeJwtResponse(response.credential);
        document.getElementById('userInfo').innerText = payload.name || payload.email || 'ব্যবহারকারী';
        document.getElementById('loginOverlay').classList.add('hidden');
        document.getElementById('appContainer').classList.remove('hidden');
        showToast(`স্বাগতম ${payload.given_name || payload.name || ''}!`);
    } catch (error) {
        showToast('Google লগইন যাচাই করা যায়নি।');
    }
}

function decodeJwtResponse(token) {
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    const jsonPayload = decodeURIComponent(atob(base64).split('').map(c =>
        '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2)
    ).join(''));
    return JSON.parse(jsonPayload);
}

function handleLogout() {
    document.getElementById('appContainer').classList.add('hidden');
    document.getElementById('loginOverlay').classList.remove('hidden');
    if (window.google && google.accounts && google.accounts.id) google.accounts.id.disableAutoSelect();
    showToast('লগআউট করা হয়েছে');
}

function switchTab(tabName) {
    document.getElementById('ai-tools').style.display = tabName === 'ai-tools' ? 'block' : 'none';
    document.getElementById('edit').style.display = tabName === 'edit' ? 'block' : 'none';
    document.getElementById('tab-ai').classList.toggle('active', tabName === 'ai-tools');
    document.getElementById('tab-edit').classList.toggle('active', tabName === 'edit');
}

function playVideo() {
    if (!video.src) return showToast('আগে একটি ভিডিও বেছে নিন।');
    video.play().then(() => showToast('ভিডিও প্লে হচ্ছে')).catch(() => showToast('ভিডিও চালানো যায়নি।'));
}
function pauseVideo() { video.pause(); showToast('ভিডিও পজ করা হয়েছে'); }
function stopVideo() { video.pause(); video.currentTime = 0; showToast('ভিডিও শুরুতে নেওয়া হয়েছে'); }

function runAutoAIEdit() {
    if (!video.src) return showToast('আগে একটি ভিডিও বেছে নিন।');
    applyFilter('sepia');
    showToast('ডেমো Auto Edit: Sepia ফিল্টার প্রয়োগ হয়েছে।');
}
function applyAIVoice() {
    showToast('এটি UI ডেমো—AI ভয়েস তৈরি করতে আলাদা AI সার্ভিস/API লাগবে।');
}
function applyAIBg() {
    showToast('এটি UI ডেমো—ব্যাকগ্রাউন্ড রিমুভ করতে AI মডেল/API লাগবে।');
}
function applyFilter(filterType) {
    const filters = {
        none: 'none', sepia: 'sepia(100%)', grayscale: 'grayscale(100%)',
        invert: 'invert(100%)', blur: 'blur(4px)'
    };
    video.style.filter = filters[filterType] || 'none';
    showToast(`ফিল্টার প্রয়োগ করা হয়েছে: ${filterType}`);
}
function triggerExport() {
    showToast('এই সংস্করণে আসল ভিডিও এক্সপোর্ট নেই; Export-এর জন্য ভিডিও প্রসেসিং যোগ করতে হবে।');
}
function showToast(message) {
    const toast = document.getElementById('toast-notification');
    toast.innerText = message;
    toast.style.display = 'block';
    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => { toast.style.display = 'none'; }, 3000);
}
