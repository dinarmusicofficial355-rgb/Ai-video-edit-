# AI Video Editor

GitHub Pages-এ প্রকাশ করার জন্য স্ট্যাটিক ওয়েবসাইট ফাইল।

## ফাইল
- `index.html` — ওয়েবসাইটের কাঠামো
- `style.css` — ডিজাইন
- `script.js` — বাটন, ভিডিও আপলোড, ফিল্টার ও Google Sign-In UI

## GitHub Pages
1. এই ZIP ফাইলটি Extract করুন।
2. GitHub repository-তে `index.html`, `style.css`, `script.js` এবং `README.md` আপলোড করুন (ZIP ফাইলের ভিতরের ফাইলগুলো, ZIP-টি নিজে নয়)।
3. Repository → Settings → Pages → Deploy from a branch → `main` / `/root` নির্বাচন করে Save করুন।

## গুরুত্বপূর্ণ
- Google লগইনের জন্য `script.js`-এ `YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com`-এর জায়গায় Google Cloud Console থেকে পাওয়া Client ID বসাতে হবে এবং অনুমোদিত JavaScript origin-এ আপনার GitHub Pages URL যোগ করতে হবে।
- AI Voiceover, Background Removal এবং Export বোতামগুলো বর্তমানে ডেমো বার্তা দেখায়; এগুলোকে বাস্তব AI/ভিডিও প্রসেসিং করতে সার্ভার বা উপযুক্ত API/লাইব্রেরি যুক্ত করতে হবে।
